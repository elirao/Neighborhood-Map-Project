Resources:
I've used Foursquare's Developer API to get some informations for some tourist places in my country.

Some of the url that I've looked to get help:

https://discussions.udacity.com/t/handling-google-maps-in-async-and-fallback/34282
https://developers.google.com/maps/documentation/javascript/tutorial#sync
https://code.sololearn.com/WQAIc8Q1YhPy/#html
https://stackoverflow.com/questions/31784200/infowindows-doesnt-show-using-google-maps-api
https://medium.com/the-web-tub/build-a-places-app-with-foursquare-and-google-maps-using-onsen-ui-and-angularjs-df44357cbe3e
https://developers.google.com/maps/documentation/javascript/infowindows
https://developers.google.com/maps/documentation/javascript/examples/infowindow-simple
https://developers.google.com/maps/documentation/javascript/examples/marker-animations
https://stackoverflow.com/questions/42735373/google-maps-javascript-make-marker-bounce
https://stackoverflow.com/questions/7339200/bounce-a-pin-in-google-maps-once/7832086
https://discussions.udacity.com/t/infowindows-bounce-working-but-infowindows-will-not-show-up/157856
https://discussions.udacity.com/t/stuck-on-showing-infowindow-content-and-binding-list-to-infowindow/21816
https://discussions.udacity.com/t/need-help-in-neighborhood-project/202387/9
https://snippetlib.com/google_maps/marker_animations
http://jsfiddle.net/manuel_guilbault/LBf8G/
http://jsfiddle.net/daedalus28/gruTF/
http://jsfiddle.net/stesta/p3ZT4/
http://knockoutjs.com/documentation/computedObservables.html
http://knockoutjs.com/documentation/dependentObservables.html

To open app, you just need to load index.html in your favorite browser :) !

